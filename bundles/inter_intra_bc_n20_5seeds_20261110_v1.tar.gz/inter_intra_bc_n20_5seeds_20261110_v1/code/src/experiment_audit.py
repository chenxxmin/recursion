"""Deterministic manifests for the paired A / A-prime format experiment."""
import hashlib
import json
from collections import Counter


def mixed_null_manifest(dataset, loader, model):
    """No random draws; labels are hashed but never included in model inputs."""
    def split_manifest(samples):
        h = hashlib.sha256()
        for values, rule_id in samples:
            h.update((json.dumps([rule_id, *values.tolist()], separators=(',', ':')) + '\n').encode())
        return dict(count=len(samples), per_rule=dict(Counter(rid for _, rid in samples)),
                    ordered_numeric_sha256=h.hexdigest())

    h = hashlib.sha256()
    for name, param in model.named_parameters():
        h.update(name.encode())
        h.update(param.detach().cpu().numpy().tobytes())
    batches = loader.batch_sampler.batches
    return dict(hash_encoding='numeric rows: compact JSON [rule_id,*values] plus LF',
                train=split_manifest(dataset.train_data), test=split_manifest(dataset.test_data),
                batch_indices_sha256=hashlib.sha256(json.dumps(batches, separators=(',', ':')).encode()).hexdigest(),
                batches_per_epoch=len(batches),
                initial_parameters_sha256=h.hexdigest())
