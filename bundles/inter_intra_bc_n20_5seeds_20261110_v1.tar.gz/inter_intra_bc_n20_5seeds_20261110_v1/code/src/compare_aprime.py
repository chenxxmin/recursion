"""Export A/A-prime observed learning curves and prespecified paired metrics.

Usage from an unpacked bundle:
python code/src/compare_aprime.py --output /path/to/run \
    --reference reference/historical_A_curves.csv --report /path/to/comparison
"""
import argparse
import ast
import csv
import json
from pathlib import Path
import re


def load_reference(path):
    result = {}
    with Path(path).open(newline='') as stream:
        for row in csv.DictReader(stream):
            result.setdefault(int(row['seed']), []).append(dict(
                steps=int(row['optimizer_steps_inferred']), epoch=int(row['epoch']),
                accuracy=float(row['test_acc_percent']) / 100,
                per_rule=ast.literal_eval(row['per_rule_acc_rounded'])))
    return result


def load_new(output):
    result = {}
    for path in sorted(Path(output).rglob('*_metrics.jsonl')):
        match = re.search(r'seed(\d+)', path.name)
        if not match:
            continue
        seed = int(match[1])
        if seed in result:
            raise ValueError(f'Multiple runs for seed {seed}; select a single run directory')
        rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        for i, row in enumerate(rows):
            if row['input_layout'] != 'numeric_null_interleaved':
                raise ValueError(f'Unexpected layout: {path}')
            if row['total'] <= 0 or row['test_accuracy'] != row['correct'] / row['total']:
                raise ValueError(f'Inconsistent exact counts: {path}')
            if i and (row['optimizer_steps'] <= rows[i-1]['optimizer_steps'] or
                      row['epoch'] <= rows[i-1]['epoch']):
                raise ValueError(f'Nonmonotonic/duplicate metrics: {path}')
        result[seed] = [dict(steps=r['optimizer_steps'], epoch=r['epoch'],
                             accuracy=r['test_accuracy'],
                             per_rule=[r['per_rule'][str(g)]['correct'] / r['per_rule'][str(g)]['total']
                                       for g in [0, 1]],
                             seen_examples=r['seen_examples'], supervised_tokens=r['supervised_tokens'])
                        for r in rows]
    return result


def compare(a, ap):
    def first(rows, threshold):
        return next((r['steps'] for r in rows if r['accuracy'] >= threshold), None)
    crossings = {}
    for threshold in [0.95, 0.99]:
        x, y = first(a, threshold), first(ap, threshold)
        crossings[str(threshold)] = dict(A=x, Aprime=y,
                                         relative_difference=(y-x)/x if x and y else None)
    by_step = {r['steps']: r for r in a}
    pairs = [(by_step[r['steps']], r) for r in ap if r['steps'] in by_step]
    mean_gap = (sum(abs(x['accuracy']-y['accuracy']) for x, y in pairs) / len(pairs) * 100
                if pairs else None)
    complete = mean_gap is not None and all(v['relative_difference'] is not None for v in crossings.values())
    within = (mean_gap <= 2 and all(abs(v['relative_difference']) <= 0.10 for v in crossings.values())
              if complete else None)
    return dict(first_logged_threshold_steps=crossings, common_observed_points=len(pairs),
                mean_absolute_gap_percentage_points=mean_gap,
                last_common_observed_step=pairs[-1][0]['steps'] if pairs else None,
                within_prespecified_tolerance=within,
                conclusion=('within_tolerance' if within else 'outside_tolerance') if complete else 'insufficient_observations',
                budget_end_actual_accuracy=next((r['accuracy'] for r in ap if r['steps'] == 270000), None),
                note='Historical A accuracy is rounded; A steps are inferred. No interpolation or post-stop filling.')


def export(output, reference, report):
    a, ap = load_reference(reference), load_new(output)
    report = Path(report)
    report.mkdir(parents=True, exist_ok=True)
    summary = {str(seed): compare(a[seed], ap.get(seed, [])) for seed in sorted(a)}
    (report/'comparison.json').write_text(json.dumps(summary, indent=2)+'\n')
    with (report/'curves.csv').open('w', newline='') as stream:
        fields = ['condition','seed','steps','epoch','accuracy','rule0_accuracy','rule1_accuracy',
                  'step_source','seen_examples','supervised_tokens']
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for name, data in [('A', a), ('Aprime', ap)]:
            for seed, rows in sorted(data.items()):
                for row in rows:
                    writer.writerow(dict(condition=name, seed=seed, steps=row['steps'], epoch=row['epoch'],
                                         accuracy=row['accuracy'], rule0_accuracy=row['per_rule'][0],
                                         rule1_accuracy=row['per_rule'][1],
                                         step_source='inferred' if name=='A' else 'counted',
                                         seen_examples=row.get('seen_examples'),
                                         supervised_tokens=row.get('supervised_tokens')))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    seeds = sorted(a)
    for kind in ['overall', 'per_rule']:
        nrows = 1 if kind == 'overall' else 2
        fig, axes = plt.subplots(nrows, len(seeds), figsize=(6*len(seeds), 3.5*nrows), squeeze=False)
        for column, seed in enumerate(seeds):
            for row_index in range(nrows):
                ax = axes[row_index, column]
                for name, rows in [('A (historical)', a[seed]), ('A-prime', ap.get(seed, []))]:
                    key = 'accuracy' if kind == 'overall' else 'per_rule'
                    ys = [(r[key] if kind == 'overall' else r[key][row_index])*100 for r in rows]
                    ax.plot([r['steps'] for r in rows], ys, label=name)
                ax.set(title=f'Seed {seed}' + (f' / rule {row_index}' if nrows==2 else ''),
                       xlabel='Optimizer updates', ylabel='Test accuracy (%)', ylim=(0, 100.5))
                ax.legend(); ax.grid(alpha=0.2)
        fig.tight_layout()
        fig.savefig(report/f'{kind}.png', dpi=180)
        fig.savefig(report/f'{kind}.pdf')
        plt.close(fig)
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reference', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(export(args.output, args.reference, args.report), indent=2))
