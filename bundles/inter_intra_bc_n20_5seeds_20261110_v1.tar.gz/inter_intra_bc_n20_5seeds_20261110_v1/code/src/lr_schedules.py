"""Explicit, checkpoint-compatible learning-rate schedules."""
import torch


def make_scheduler(optimizer, kind, epochs):
    if kind == 'cosine':
        return torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)
    if kind == 'constant':
        return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda _: 1.0)
    raise ValueError(f'Unknown LR_SCHEDULE: {kind!r}')
