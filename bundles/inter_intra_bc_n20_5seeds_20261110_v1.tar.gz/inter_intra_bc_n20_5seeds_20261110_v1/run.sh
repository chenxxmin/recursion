#!/usr/bin/env bash
set -euo pipefail
BUNDLE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${EXPERIMENT_PYTHON:-python3}"
# 每个实验单独计时，单位小时；null=不限。达到时限后在 eval 点保存退出。
# 定时由训练循环 MAX_TRAIN_HOURS 执行，不改变 EPOCHS，不使用强杀。
TIMERS_JSON='{"inter_intra_b_o2_P127_N20_d1024l2h4r4_len16_seed34789":null,"inter_intra_b_o2_P127_N20_d1024l2h4r4_len16_seed44536":null,"inter_intra_b_o2_P127_N20_d1024l2h4r4_len16_seed66601":null,"inter_intra_c_o2_P127_N20_d1024l2h4r4_len16_seed18318":null,"inter_intra_c_o2_P127_N20_d1024l2h4r4_len16_seed34789":null,"inter_intra_c_o2_P127_N20_d1024l2h4r4_len16_seed44536":null,"inter_intra_c_o2_P127_N20_d1024l2h4r4_len16_seed66601":null}'
exec "$PYTHON_BIN" "$BUNDLE_DIR/runner.py" --bundle "$BUNDLE_DIR" --timers "$TIMERS_JSON" "$@"
