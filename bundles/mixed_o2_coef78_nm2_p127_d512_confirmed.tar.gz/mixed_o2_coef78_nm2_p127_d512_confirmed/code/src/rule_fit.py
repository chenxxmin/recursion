"""Fit linear recurrence formulas to trained models' predictions, over F_p.

Given an experiment batch NAME, this script:
  1. reads experiments/<name>.json and iterates its experiments
  2. finds the training log and the model checkpoint for each experiment
  3. dumps the attention matrix from the log as a symbol grid
     (　<0.05, · 0.05~0.1, ○ 0.1~0.25, × 0.25~0.5, ※ 0.5~1)
  4. MISSING-MODE (experiments with MISSING_PROB > 0): queue-driven BFS over
     corruption patterns, rooted at ALL length-init_len patterns. Per pattern:
     model-vs-truth agreement + live attention (real corrupted sequences),
     then a coefficient fit on attention-significant visible distances using
     RANDOM off-manifold probes (only the pattern's own window is forced
     masked). Reliable fit (agreement >= 0.9): enqueue the pattern with each
     used position masked; unreliable: refine one position deeper (both
     states). Pattern length cap --depth (default 8)
  5. otherwise positions are segmented by ATTENTION SIGNATURE (unchanged)
  6. PROBE DATA: fully random sequences in both modes (missing mode forces
     the pattern's window masks; attention mode is uncorrupted)
  7. reports experiments with missing log/model at the end

Paths:
  model: /mnt/workspace/hujiachen/models/<name>/<exp>.pth
  log:   /mnt/workspace/hujiachen/models/<name>/logs/<exp>.log  or
         /mnt/workspace/hujiachen/recursion_results/<name>/logs/<exp>.log

Usage (repo root):
    python src/rule_fit.py <name>                 # batch mode: iterate experiments/<name>.json
    python src/rule_fit.py <name> <exp_name>      # single experiment of the batch:
                                                  # <name> = model dir + JSON name,
                                                  # <exp_name> = .pth stem + JSON entry name
    python src/rule_fit.py <model.pth> <cfg.json> # single-model mode: match the
                                                  # experiment by pth filename stem
    [--samples N] [--seed N] [--length L] [--min-seg N] [--depth N] [--min-n N]

Output is teed to rule_fit_output.log.
"""
import argparse
import contextlib
import itertools
import json
import os
import random
import sys

import torch

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from analyze_attention import extract_qk_raw_scores, load_model
from datasets import corrupt_window
from report_front_back_attention import (dump_matrices, parse_log,
                                         segment_by_attention)
from rules import task_from_save_config
from verify_sample import _Tee, build_single_rule

MODEL_BASE = '/mnt/workspace/hujiachen/models'
LOG_BASE_CANDIDATES = ['/mnt/workspace/hujiachen/models/{name}/logs', '/mnt/workspace/hujiachen/recursion_results/{name}/logs']
SIG_THRESHOLD = 0.10  # attention values below this are ignored in signatures


def solve_mod_p(rows, p):
    """Exact linear solve over F_p via Gaussian elimination.

    rows: list of [x1..xk, y]. Returns the coefficient list when the system
    has a unique exact solution, else None (inconsistent or underdetermined).
    """
    A = [[v % p for v in r] for r in rows]
    k = len(A[0]) - 1
    piv_row = 0
    for col in range(k):
        piv = next((r for r in range(piv_row, len(A)) if A[r][col] != 0), None)
        if piv is None:
            return None
        A[piv_row], A[piv] = A[piv], A[piv_row]
        inv = pow(A[piv_row][col], p - 2, p)
        A[piv_row] = [v * inv % p for v in A[piv_row]]
        for r in range(len(A)):
            if r != piv_row and A[r][col] != 0:
                f = A[r][col]
                A[r] = [(a - f * b) % p for a, b in zip(A[r], A[piv_row])]
        piv_row += 1
        if piv_row == len(A):
            break
    if piv_row < k:
        return None
    for r in A:
        if all(v == 0 for v in r[:k]) and r[k] != 0:
            return None
    return [A[r][k] for r in range(k)]


def fit_and_score(X, y, p, rounds=300):
    """Return (coeffs, agreement, exact). Exact solve first; RANSAC fallback."""
    k = len(X[0])
    coeffs = solve_mod_p([xi + [yi] for xi, yi in zip(X, y)], p)
    if coeffs is not None:
        return coeffs, 1.0, True
    best_c, best_acc = None, -1.0
    for _ in range(rounds):
        idx = random.sample(range(len(X)), k)
        c = solve_mod_p([[X[i][j] for j in range(k)] + [y[i]] for i in idx], p)
        if c is None:
            continue
        acc = sum(1 for xi, yi in zip(X, y)
                  if sum(ci * vi for ci, vi in zip(c, xi)) % p == yi) / len(X)
        if acc > best_acc:
            best_c, best_acc = c, acc
    return best_c, best_acc, False


EXPAND_MIN_AGREEMENT = 0.8   # at least this agreement for the fit to print and to drive expansion
FIT_MAX_ROWS = 2000          # cap equations fed to fit_and_score (RANSAC scoring cost)
PROBE_ATTN_SAMPLES = 100     # probes used to measure per-distance attention for set C
INFLUENCE_PROBES = 100       # probes per pattern for counterfactual influence
INFLUENCE_MIN = 0.5          # change rate at which a distance counts as "read"


def visible_distance(P, d):
    """True if distance d (0 = last token) is visible in pattern P (oldest-first
    mask tuple). Distances beyond the window are always visible: probes only
    force masks inside the window."""
    L = len(P)
    return d >= L or not P[L - 1 - d]


def patt_label(P):
    return '(' + ','.join('M' if m else 'x' for m in P) + ')'


def mask_children(P, deps, d_max):
    """One child per dependency distance: that distance additionally masked.
    The window extends left (new positions default to visible) when the
    dependency lies outside it; children longer than d_max are dropped."""
    L = len(P)
    children = []
    for d in sorted(deps):
        new_len = max(L, d + 1)
        if new_len > d_max:
            continue
        child = [False] * new_len
        for k in range(L):
            child[new_len - L + k] = P[k]
        child[new_len - 1 - d] = True
        children.append(tuple(child))
    return children


def refine_children(P, d_max):
    """Both states (visible, masked) of the next-deeper position, prepended to
    the window — used when the fit is unreliable, i.e. the pattern is likely a
    mixture of deeper sub-patterns. Empty when the window is at d_max."""
    if len(P) + 1 > d_max:
        return []
    return [(False,) + P, (True,) + P]


def aggregate_buckets(buckets, P, d_max):
    """Sum (n, agree) over the depth-d_max bucket records whose length-len(P)
    suffix equals P."""
    L = len(P)
    n, agree = 0, 0
    for B, rec in buckets.items():
        if B[d_max - L:] != P:
            continue
        n += rec['n']
        agree += rec['agree']
    return n, agree


def select_C(attn, P, threshold=SIG_THRESHOLD):
    """Hypothesis set: distances whose merged mean attention reaches `threshold`
    in any (layer, head), restricted to distances visible in P, sorted."""
    sig = set()
    for dd in attn.values():
        for d, (s, c) in dd.items():
            if s / c >= threshold:
                sig.add(d)
    return sorted(d for d in sig if visible_distance(P, d))


def rule_coeffs(next_fn, init_len, p):
    """Extract a linear rule's coefficients by probing next_fn with one-hot
    histories. Returns ([c_d0, c_d1, ...], base); meaningful for linear rules
    (addition/tribonacci) only."""
    base = next_fn([0] * init_len)
    coeffs = []
    for d in range(init_len):
        v = [0] * init_len
        v[init_len - 1 - d] = 1
        coeffs.append((next_fn(v) - base) % p)
    return coeffs, base


def probe_equations(model, P, C, length, n_probes, p):
    """Random off-manifold probes for pattern P: iid uniform sequences with only
    P's own window positions forced to the missing token; everything else stays
    visible. Random features are full-rank, so fitting C's coefficients is
    always solvable (unlike on-manifold windows, which are rank-deficient for
    k > recurrence order). Returns (X, y): features at distances C, target =
    model prediction at each window end."""
    L = len(P)
    c_max = max(C)
    # window ends are spaced so other windows' forced masks can never land
    # within [t - c_max, t] of a sampled window end
    t0 = max(L - 1, c_max)
    ts = list(range(t0, length - 1, L + c_max))
    X, y = [], []
    for _ in range(n_probes):
        view = [random.randrange(p) for _ in range(length)]
        for t in ts:
            for k in range(L):
                if P[k]:
                    view[t - L + 1 + k] = p
        x = torch.tensor([view], dtype=torch.long)
        with torch.no_grad():
            preds = model(x)[0][0].argmax(dim=-1).tolist()
        for t in ts:
            X.append([view[t - d] for d in C])
            y.append(preds[t])
    return X, y


def probe_attention(model, P, length, n_probes, p):
    """Per-distance attention measured on random probes for pattern P: one
    window per probe (P's masks forced at the last predictable position,
    everything else clean and random), so no neighbouring forced mask can
    pollute the measurement. Returns {(li,h): {d: [sum, cnt]}} — the same
    structure select_C consumes. Measuring on the probe distribution (not the
    real-data mixture) keeps C matched to the data the fit actually sees:
    sub-pattern mixing is handled by the BFS refining deeper nodes."""
    L = len(P)
    t = length - 2  # last predictable position
    attn = {}
    for _ in range(n_probes):
        view = [random.randrange(p) for _ in range(length)]
        for k in range(L):
            if P[k]:
                view[t - L + 1 + k] = p
        x = torch.tensor([view], dtype=torch.long)
        with torch.no_grad():
            attn_layers = [lo_['attn_weights'] for lo_ in extract_qk_raw_scores(model, x)]
        for li, att in enumerate(attn_layers):
            row_all = att[:, t, :]  # (H, T)
            for h in range(att.shape[0]):
                acc = attn.setdefault((li, h), {})
                row = row_all[h]
                for d in range(t + 1):
                    v = row[t - d].item()
                    if d in acc:
                        acc[d][0] += v
                        acc[d][1] += 1
                    else:
                        acc[d] = [v, 1]
    return attn


def position_influence(model, P, C, length, n_probes, p):
    """Counterfactual per-distance influence for pattern P: on random probes
    with P's window forced at the last predictable position, resample each
    hypothesis position in turn (to a different random value) and measure how
    often the prediction at the window end changes. No linearity assumption —
    this answers "which positions does the model actually read" even when no
    stable linear formula exists (e.g. content-dependent attention drift).
    Returns {d: change rate}."""
    L = len(P)
    t = length - 2  # last predictable position
    changed = {d: 0 for d in C}
    for _ in range(n_probes):
        view = [random.randrange(p) for _ in range(length)]
        for k in range(L):
            if P[k]:
                view[t - L + 1 + k] = p
        with torch.no_grad():
            base = model(torch.tensor([view], dtype=torch.long))[0][0].argmax(dim=-1)[t].item()
        for d in C:
            new = random.randrange(p - 1)
            if new >= view[t - d]:
                new += 1  # resample to a DIFFERENT value
            perturbed = list(view)
            perturbed[t - d] = new
            with torch.no_grad():
                pred = model(torch.tensor([perturbed], dtype=torch.long))[0][0].argmax(dim=-1)[t].item()
            changed[d] += (pred != base)
    return {d: c / n_probes for d, c in changed.items()}


def fmt_equation(dists, coeffs, p):
    """Format the fitted formula, dropping zero-coefficient terms."""
    terms = ' + '.join(f'{c}*x_{{t-{d}}}' if d else f'{c}*x_t'
                       for d, c in zip(dists, coeffs) if c % p != 0)
    return f'x_{{t+1}} = {terms or "0"}  (mod {p})'


def run_missing_categories(args, model, cfg, next_fn, init_len, p, exp_name, desc):
    """Missing-experiment mode, queue-driven edition.

    BFS over corruption patterns rooted at the all-visible pattern
    (x,)*init_len. Pass 1 buckets positions of real corrupted recurrence
    sequences by the depth-d_max pattern (shorter patterns are derived by
    suffix merges). The queue starts from ALL length-init_len patterns
    ((x,x), (x,M), (M,x), (M,M) for order-2 rules). Each queued pattern with
    n >= min-n reports:
      - model-vs-truth agreement (real corrupted sequences)
      - a coefficient fit over the attention-significant visible distances
        (set C), done on RANDOM off-manifold probes (probe_equations); C
        itself is measured on the SAME probe distribution (probe_attention),
        so sub-pattern mixing never contaminates it
    Expansion (expansion itself is always attempted, up to pattern length
    d_max (default 8; --depth overrides)):
      - reliable fit (agreement >= EXPAND_MIN_AGREEMENT): the formula's
        nonzero-coefficient distances are the rule's inputs; for each one,
        the pattern with that distance additionally masked is enqueued
        (mask_children, dedup via visited/queue)
      - unreliable or no fit: the pattern is likely a mixture of deeper
        sub-patterns, so both states of the next-deeper position are
        enqueued (refine_children)
    Probe fitting targets single-layer models (a warning is printed otherwise).
    """
    length = args.length or cfg.get('TRAIN_LEN', 16)
    num_mask = cfg.get('NUM_MASK') or 0
    missing_prob = cfg['MISSING_PROB']
    miss_len = cfg.get('MISS_LEN', 1)
    d_max = args.depth or 8
    min_n = args.min_n
    start = max(max(num_mask, 1), d_max - 1)

    if len(model.transformer.h) > 1:
        print('[warn] probe fitting targets single-layer models; multi-layer '
              'off-manifold results need separate interpretation')

    # --- pass 1: real recurrence sequences, naturally corrupted; bucket every
    # position by the corruption pattern of its last d_max tokens
    buckets = {}  # pattern tuple (len d_max) -> {'n','agree'}
    for _ in range(args.samples):
        seq = [random.randrange(p) for _ in range(init_len)]
        while len(seq) < length:
            seq.append(next_fn(seq))
        window = torch.tensor(seq, dtype=torch.long)
        # single-rule only here, so the missing token is plain p
        corrupt_window(window, True, p=p, init_len=init_len, missing_prob=missing_prob,
                       miss_len=miss_len)
        view = window.tolist()
        x = torch.tensor([view], dtype=torch.long)
        with torch.no_grad():
            preds = model(x)[0][0].argmax(dim=-1).tolist()

        for t in range(start, length - 1):
            patt = tuple(view[t - d_max + 1 + k] == p for k in range(d_max))
            rec = buckets.get(patt)
            if rec is None:
                rec = buckets[patt] = {'n': 0, 'agree': 0}
            rec['n'] += 1
            if preds[t] == seq[t + 1]:
                rec['agree'] += 1

    print(f'Model: {exp_name}')
    print(f'Rule : {desc} | length={length}, missing prob={missing_prob}, '
          f'miss_len={miss_len}, max pattern depth={d_max}')

    # --- pass 2: BFS over patterns, starting from all length-init_len patterns
    root = (False,) * init_len
    roots = list(itertools.product((False, True), repeat=init_len))
    print(f'Queue-driven analysis: roots {", ".join(patt_label(r) for r in roots)}; '
          f'reliable fit -> mask each used position, unreliable -> refine one deeper')
    visited = set()
    queue = list(roots)
    while queue:
        P = queue.pop(0)
        if P in visited or len(P) > d_max:
            continue
        visited.add(P)
        n, agree = aggregate_buckets(buckets, P, d_max)
        if n < min_n:
            continue

        # set C comes from attention measured on the probe distribution itself
        C = select_C(probe_attention(model, P, length, PROBE_ATTN_SAMPLES, p), P)
        if not C:
            continue
        X, y = probe_equations(model, P, C, length, args.samples, p)
        if len(X) > FIT_MAX_ROWS:
            idx = random.sample(range(len(X)), FIT_MAX_ROWS)
            X = [X[i] for i in idx]
            y = [y[i] for i in idx]
        coeffs, acc_fit, exact = fit_and_score(X, y, p)
        probe_ok = coeffs is not None and (exact or acc_fit >= EXPAND_MIN_AGREEMENT)

        # probe fit unreliable: with --influence, measure per-distance
        # influence — which positions the model reads is meaningful even when
        # no stable linear formula exists (e.g. content-dependent attention
        # drift). Off by default: on real models the flip-rate noise floor is
        # high (perturbing a position also shifts attention), which made the
        # output muddier than formula-only reporting.
        influence = None
        if not probe_ok and args.influence:
            influence = position_influence(model, P, C, length, INFLUENCE_PROBES, p)
        sig = {d for d, r in (influence or {}).items() if r >= INFLUENCE_MIN}

        # expansion: a trustworthy fit's nonzero coefficients (or, failing
        # that, the influence-significant distances) are the positions the
        # model reads — enqueue the pattern with each of them masked. Nothing
        # readable means a likely mixture — refine one position deeper.
        if probe_ok:
            deps = {d for d, c in zip(C, coeffs) if c != 0}
            children = mask_children(P, deps, d_max)
        elif sig:
            children = mask_children(P, sig, d_max)
        else:
            children = refine_children(P, d_max)
        children = [c for c in children if c not in visited and c not in queue]
        queue.extend(children)

        # print only nodes with something trustworthy to say: a good formula,
        # or at least significant per-position influence
        if probe_ok:
            print(f'\n== pattern {patt_label(P)}  n={n}, model-vs-truth {agree / n:.1%}')
            tag = 'EXACT' if exact else f'agreement {acc_fit:.1%}'
            print(f'  set C {C}: {fmt_equation(C, coeffs, p)}  [{tag}, probe n={len(X)}]')
        elif sig:
            print(f'\n== pattern {patt_label(P)}  n={n}, model-vs-truth {agree / n:.1%}')
            print('  influence: ' + ' '.join(
                f'd{d}:{r:.2f}' for d, r in sorted(influence.items()) if r >= SIG_THRESHOLD))
        else:
            continue

        if P == root:
            rc, base = rule_coeffs(next_fn, init_len, p)
            fit_map = {d: c % p for d, c in zip(C, coeffs)}
            ok = (base % p == 0
                  and all(fit_map.get(d, 0) == rc[d] for d in range(init_len))
                  and all(c % p == 0 for d, c in fit_map.items() if d >= init_len))
            print(f'  root check: training rule coeffs {rc} -> {"MATCH" if ok else "MISMATCH"}')
    print()


def run_one(args, exp_cfg, task, exp_name, pth_path, log_path):
    model, checkpoint = load_model(pth_path, device='cpu')
    cfg = dict(exp_cfg)
    cfg['P'] = cfg.get('P', cfg.get('p'))
    if task is None:
        # checkpoint fallback: task_from_save_config 新块优先；None = mixed/action
        task = task_from_save_config(checkpoint['config'])
        if task is None:
            task = checkpoint['config'].get('recurrence') or 'mixed_ab'
    if task in ('mixed', 'mixed_ab', 'mixed_abc', 'action', 'action_trib', 'dynamic_mixed'):
        print('[skip] rule_fit supports single-rule scenarios only')
        return
    if task == 'single' and 'RULES' not in cfg and 'rules' not in cfg:
        # 新 checkpoint 的系数在 save_config 的 rules 键里
        cfg['rules'] = checkpoint['config'].get('rules')

    init_len, next_fn, desc = build_single_rule(task, cfg)
    p = cfg['P']
    num_mask = cfg.get('NUM_MASK') or 0
    random.seed(args.seed)

    # missing experiments: group by corruption pattern of the last two context
    # tokens instead of attention signatures
    if cfg.get('MISSING_PROB', 0.0) > 0 and not args.clean:
        run_missing_categories(args, model, cfg, next_fn, init_len, p, exp_name, desc)
        return

    # --- log: attention matrices + signature segmentation
    if log_path is None:
        print('[skip] attention mode needs the training log (none found for this model)')
        return
    start_x, series, attn = parse_log(log_path)
    if not attn:
        print('[skip] no attention section in log')
        return
    T_att = max(i for layer in attn.values() for head in layer.values() for i in head) + 1
    # probe length must cover the attention matrix coordinates, otherwise
    # segments beyond TRAIN_LEN would have no data
    length = args.length or max(cfg.get('TRAIN_LEN', 16), T_att)
    segments = segment_by_attention(attn, start_pos=num_mask - 1,
                                    threshold=SIG_THRESHOLD)
    if args.min_seg > 1:
        segments = _merge_short_segments(segments, args.min_seg)

    print(f'Model: {exp_name}')
    print(f'Rule : {desc} | probe length={length}, num_mask={num_mask}')
    print(f'Segments (signature = significant attention dists, union over heads):')
    for a, b, sig in segments:
        print(f'  positions {a:2d}..{b:2d}  dists={sorted(sig)}')

    # attention symbol grids
    dump_matrices(attn, print, exp_name)

    # --- probe: fully random sequences (off-manifold by design)
    # every segment position contributes exactly args.samples equations
    set_A = list(range(init_len))
    buckets = {}   # (seg_idx, 'A'|'C') -> (X, y)
    agree = {}     # seg_idx -> [match, total]  (model pred vs random-seq "truth" is
                   # meaningless here; instead report pred == recurrence continuation)
    for i, (a, b, sig) in enumerate(segments):
        buckets[(i, 'A')] = ([], [])
        buckets[(i, 'C')] = ([], [])
        agree[i] = [0, 0]

    for _ in range(args.samples):
        seq = [random.randrange(p) for _ in range(length)]
        x = torch.tensor([seq], dtype=torch.long)
        with torch.no_grad():
            preds = model(x)[0][0].argmax(dim=-1).tolist()
        for i, (a, b, sig) in enumerate(segments):
            dists_C = sorted(set(set_A) | set(sig))
            for t in range(max(a, 0), min(b, length - 2) + 1):
                pred = preds[t]
                # reference: what the TRUE rule would predict from the last
                # init_len tokens of the random probe
                agree[i][1] += 1
                if t + 1 >= init_len and pred == next_fn(seq[:t + 1]):
                    agree[i][0] += 1
                for label, dists in (('A', set_A), ('C', dists_C)):
                    feats = [seq[t - d] for d in dists if t - d >= 0]
                    if len(feats) < len(dists):
                        continue
                    buckets[(i, label)][0].append(feats)
                    buckets[(i, label)][1].append(pred)

    # --- fit and report per segment
    seg_results = []  # (a, b, sig, {label: (dists, coeffs, acc, exact)})
    for i, (a, b, sig) in enumerate(segments):
        m, tot = agree[i]
        line = f'\n== segment {i} (positions {a}..{b}), signature {sorted(sig)}'
        if tot:
            line += f' | pred == true-rule-on-random-input {m}/{tot} = {m / tot:.1%}'
        print(line)
        fits = {}
        for label in ('A', 'C'):
            dists = set_A if label == 'A' else sorted(set(set_A) | set(sig))
            X, y = buckets[(i, label)]
            if not X:
                fits[label] = (dists, None, 0.0, False)
                print(f'  set {label} {dists}: no usable positions')
                continue
            coeffs, acc, exact = fit_and_score(X, y, p)
            fits[label] = (dists, coeffs, acc, exact)
            if coeffs is None:
                print(f'  set {label} {dists}: no linear fit (best agreement {acc:.1%})')
            else:
                tag = 'EXACT' if exact else f'best-effort, agreement {acc:.1%}'
                print(f'  set {label} {dists}: {fmt_equation(dists, coeffs, p)}  [{tag}]')
        seg_results.append((a, b, sig, fits))

    # --- merge adjacent segments with identical fitted formula (set C).
    # Normalization DROPS zero coefficients, so e.g. signature [0,1,6] with
    # coeffs (c0, 0, c6) merges with [0,6] with coeffs (c0, c6).
    def norm_C(fits):
        dists, coeffs, acc, exact = fits['C']
        if coeffs is None:
            return None
        return {d: c % p for d, c in zip(dists, coeffs) if c % p != 0}

    print('== merged formula groups (adjacent segments, identical formula):')
    groups = []  # each: [start, end, formula_dict, member segment idxs, min_acc, all_exact]
    for i, (a, b, sig, fits) in enumerate(seg_results):
        f = norm_C(fits)
        acc = fits['C'][2]
        exact = fits['C'][3]
        if groups and f is not None and groups[-1][2] == f:
            g = groups[-1]
            g[1] = b
            g[3].append(i)
            g[4] = min(g[4], acc)
            g[5] = g[5] and exact
        else:
            groups.append([a, b, f, [i], acc, exact])
    for ga, gb, gf, members, min_acc, all_exact in groups:
        if gf is None:
            print(f'  positions {ga:2d}..{gb:2d}  (segments {members}): no linear fit')
            continue
        dists = sorted(gf)
        coeffs = [gf[d] for d in dists]
        tag = 'EXACT' if all_exact else f'min agreement {min_acc:.1%}'
        print(f'  positions {ga:2d}..{gb:2d}  (segments {members}): '
              f'{fmt_equation(dists, coeffs, p)}  [{tag}]')
    print()


def _merge_short_segments(segments, min_len):
    """Merge runs shorter than min_len into the previous segment (or the next
    one when there is no previous)."""
    segs = [[a, b, sig] for a, b, sig in segments]
    i = 0
    while i < len(segs):
        if segs[i][1] - segs[i][0] + 1 < min_len and len(segs) > 1:
            if i == 0:
                segs[1][0] = segs[0][0]
            else:
                segs[i - 1][1] = segs[i][1]
            del segs[i]
            i = max(i - 1, 0)
        else:
            i += 1
    return [(a, b, sig) for a, b, sig in segs]


def main():
    ap = argparse.ArgumentParser(description='Fit linear formulas to model predictions over F_p.')
    ap.add_argument('name', help='experiment batch name (experiments/<name>.json), '
                                 'or a .pth path for single-model mode')
    ap.add_argument('arg2', nargs='?', default=None,
                    help='batch mode: experiment name — analyze only this one; '
                         'single-model mode: experiments JSON to match the pth filename stem')
    ap.add_argument('--samples', type=int, default=500,
                    help='random probe sequences per model (each position contributes one equation per sequence)')
    ap.add_argument('--seed', type=int, default=0)
    ap.add_argument('--length', type=int, default=None, help='probe length (default: TRAIN_LEN)')
    ap.add_argument('--min-seg', type=int, default=1,
                    help='merge segments shorter than this into neighbours (default 1 = literal rule)')
    ap.add_argument('--depth', type=int, default=None,
                    help='missing mode: max pattern length (default 8)')
    ap.add_argument('--min-n', type=int, default=20,
                    help='missing mode: only print patterns with at least this many positions')
    ap.add_argument('--influence', action='store_true',
                    help='missing mode: when the probe fit fails, report per-position '
                         'influence (counterfactual perturbation) and let it drive expansion')
    ap.add_argument('--clean', action='store_true',
                    help='attention mode: do not corrupt; also forces attention mode for missing experiments')
    args = ap.parse_args()

    out_path = 'rule_fit_output.log'

    # ---- single-model mode: rule_fit model.pth config.json
    if args.name.endswith('.pth'):
        pth = args.name
        if not args.arg2:
            ap.error('single-model mode needs the experiments JSON as second argument')
        with open(args.arg2, encoding='utf-8') as f:
            experiments = json.load(f)['experiments']
        stem = os.path.splitext(os.path.basename(pth))[0]
        match = next((e for e in experiments if e['name'] == stem), None)
        if match is None:
            print(f'[error] {stem} not found in {args.arg2}')
            return
        batch = os.path.splitext(os.path.basename(args.arg2))[0]
        log = next((cand for cand in
                    (os.path.join(base.format(name=batch), f'{stem}.log')
                     for base in LOG_BASE_CANDIDATES)
                    if os.path.exists(cand)), None)
        with open(out_path, 'w', encoding='utf-8') as f:
            with contextlib.redirect_stdout(_Tee(sys.stdout, f)):
                try:
                    run_one(args, match['config'], match.get('task'), stem, pth, log)
                except Exception as exc:
                    print(f'[error] {type(exc).__name__}: {exc}')
        print(f'\n[output saved to {out_path}]')
        return

    # ---- batch mode: rule_fit <batch> [exp_name]
    # <batch> is both the models/logs directory name and experiments/<batch>.json;
    # [exp_name] (optional) is both the .pth filename stem and the JSON entry name
    exp_path = f'experiments/{args.name}.json'
    batch = args.name
    only_exp = args.arg2
    if not os.path.exists(exp_path):
        print(f'[error] batch not found: {exp_path}')
        return
    with open(exp_path, encoding='utf-8') as f:
        experiments = json.load(f)['experiments']
    if only_exp:
        experiments = [e for e in experiments if e['name'] == only_exp]
        if not experiments:
            print(f'[error] {only_exp} not found in {exp_path}')
            return

    out_path = 'rule_fit_output.log'
    missing = []
    with open(out_path, 'w', encoding='utf-8') as f:
        with contextlib.redirect_stdout(_Tee(sys.stdout, f)):
            for e in experiments:
                exp_name, task, exp_cfg = e['name'], e.get('task'), e['config']
                print('=' * 78)
                print(f'# {exp_name}')
                print('=' * 78)
                pth = os.path.join(MODEL_BASE, batch, f'{exp_name}.pth')
                log = next((cand for cand in
                            (os.path.join(base.format(name=batch), f'{exp_name}.log')
                             for base in LOG_BASE_CANDIDATES)
                            if os.path.exists(cand)), None)
                if not os.path.exists(pth):
                    missing.append((exp_name, 'model'))
                    print(f'[skip] model not found: {pth}')
                    continue
                if log is None:
                    missing.append((exp_name, 'log'))
                    print(f'[skip] log not found for {exp_name}')
                    continue
                try:
                    run_one(args, exp_cfg, task, exp_name, pth, log)
                except Exception as exc:
                    missing.append((exp_name, f'error: {type(exc).__name__}: {exc}'))
                    print(f'[error] {type(exc).__name__}: {exc}')

            print('=' * 78)
            print(f'MISSING REPORT ({len(missing)}/{len(experiments)} skipped):')
            for exp_name, why in missing:
                print(f'  {exp_name}: {why}')
            if not missing:
                print('  none — all experiments processed')
    print(f'\n[output saved to {out_path}]')


if __name__ == '__main__':
    main()
