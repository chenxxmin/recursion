# 已确认 A′ / B / C 合并运行包

共11条：B三条（34789/44536/66601）、C四条（18318/34789/44536/66601）、
三规则A′四条（17996/18318/34789/44536），最大并发2。
用户确认和修订见 [APPROVAL.json](APPROVAL.json)，完整参数见 [PARAMETERS.md](PARAMETERS.md)。

B按用户要求显式NUM_MASK=1。action场景使用数据集loss_mask，B/C均监督q3–q16（14个数值）；
C保留原NUM_MASK=null，A′为NUM_MASK=2、监督q4–q16（13个数值）及0.5辅助分类损失。
B从null改1后输入/mask/logits/loss完全一致，见validation/action_mask_audit.json。
A′四种子的全量历史参考审计见validation/aprime_n3_audit.json。

A′需要本包中的三规则NULL代码，请使用本包启动；单独JSON不能保证旧版仓库具备该功能。
所有实验从零训练、无墙钟时限，cosine上限6000轮，其他早停规则仍生效。
若已经运行旧B/C，可用--only选择新增A′子集，实验名称见experiments.json。

Linux；Python 3.10+；预先安装匹配目标机器 CUDA 的 PyTorch 及 requirements.txt 中的依赖。
本包包含当前实际代码快照，不依赖目标机器旧仓库。

检查：bash run.sh check

启动：bash run.sh run --gpus 0,1 --output /your/output --background

分发到多机时，用 --only experiment_name[,experiment_name] 选择各机负责的实验。

空闲排队：bash run.sh run --gpus 2,3,0,1 --output /your/output --wait-for-idle --poll-seconds 300 --background

排队时GPU列表是候选池；一张空闲即可先启动一条，等待不计入训练预算。

进度：bash run.sh status --output /your/output

存档停止：bash run.sh stop --output /your/output

EXPERIMENT_PYTHON 环境变量可指定 Python。输出目录必须全新，避免覆盖旧结果。
每条定时见 run.sh 中 TIMERS_JSON 和 PARAMETERS.md；从进入训练循环开始独立计时，到下一个 eval 点完整存盘，退出码 42 为正常定时/手动存档退出。无定时为 null。设定时限是训练上限，不含排队和初始化；早停条件仍生效。
参数修改后应重新审阅打包；运行脚本只允许选择 GPU、输出位置和实验子集。
在线 train 指标不是固定权重全训练集评估；本包不自动添加额外实验或全量复评。
